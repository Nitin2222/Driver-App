import { Component, Input, OnChanges } from '@angular/core';

@Component({
    selector: 'ct-table',
    templateUrl: 'app/shared/table-layout.component.html'
})
export class TableLayoutComponent implements OnChanges{

  pointsMap:Object = {'1':100,'2':50,'3':25};
  @Input() set records(rec:any[]) {
      this._records = rec;
      this.originalData = [];
     this._records.forEach((x) => {
    this.originalData.push(x);

  })
        
  };

  get records():any[] {
      return this._records;
  }
  @Input() caption: string;
  keys: string[];
  filterKey: any;
  filterValue: any;
  originalData:any[];
  arrayToBeMatched:Object;
  map:Object;

  _records:any[];

  a:any[] = [1,2,3]
  ngOnChanges() {
        this.keys = Object.keys(this.records[0]);
    }
   
   onChange(event:any,test) {
       console.log(test);
       this.filterKey = event.target.id;
       this.filterValue = ""+test;
       console.log(this.originalData.length);
       if(test === ''){
         this._records = this.originalData;
       }
       else{
        this._records = this.records.filter((element,index,array) => this.filter(element,index,array));
       }
       
   }

    filter(element, index, array) { 
      return this.map[element.id ] >0; 
  }
        
  

matchSegment(input:string) {
  
 for (var prop in this.arrayToBeMatched) {
       
      var subArray:any[] = this.arrayToBeMatched[prop];
      for (var j=0; j<subArray.length; j++) {
          var valueToBeMatched:any = subArray[j];
          if(isNaN(parseFloat(valueToBeMatched)) && isNaN(parseFloat(input))) {
             if(valueToBeMatched.indexOf(input) >= 0) {
                 this.map[prop]++;
             }
          }
          else if(!isNaN(parseFloat(valueToBeMatched)) && !isNaN(parseFloat(input))){
               var num1:number = parseFloat(valueToBeMatched);
               var num2:number = parseFloat(input);

               if(num2 >= num1+10 && num2 <= num1-10) {
                   this.map[prop]++;
               }
          }

      }
  }
}



  onDelete(record:any) {
      console.log(record);
      this.originalData = this.removeFromArray(this.originalData,record.id);
      this._records = this.removeFromArray(this._records,record.id);
  }

  removeFromArray(originalArray:any[],id:number):any[] {
      var arr:any[];
      for(var i=0; i<originalArray.length; i++ ) {
          if((originalArray[i]).id === id) {
            arr =  originalArray.splice(i,1);
              break;
          }
      }
      return originalArray;
  }

  clearMap(inputRecords:any[]) {
      this.map = {};
     for(var i=0; i<inputRecords.length;i++) {
      this.map[inputRecords[i].id] = 0;
  } 

  
}

onChangeInput(id:string,value:number, key:string) {
     let record: any =this._records[id];
      if(key === 'Wins') {
            record.Points = value* 25 + this.pointsMap[record.Position] ;
      }
      else {
          record.Points = record.Wins* 25 + this.pointsMap[value] ;
      }
      
      if(isNaN(record.Points)) {
          record.Points = '';
      }
  }
}
 
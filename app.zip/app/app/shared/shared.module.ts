import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormatCellPipe } from './format-cell.pipe';
import { StyleCellDirective } from './style-cell.directive';

import { TableLayoutComponent } from './table-layout.component';

@NgModule({
    imports: [ CommonModule ],
    declarations: [ TableLayoutComponent, FormatCellPipe, StyleCellDirective ],
    exports: [
        CommonModule, 
        TableLayoutComponent,
        FormatCellPipe,
        StyleCellDirective 
    ]
})
export class SharedModule { }
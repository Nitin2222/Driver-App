"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var TableLayoutComponent = (function () {
    function TableLayoutComponent() {
        this.pointsMap = { '1': 100, '2': 50, '3': 25 };
        this.a = [1, 2, 3];
    }
    Object.defineProperty(TableLayoutComponent.prototype, "records", {
        get: function () {
            return this._records;
        },
        set: function (rec) {
            var _this = this;
            this._records = rec;
            this.originalData = [];
            this._records.forEach(function (x) {
                _this.originalData.push(x);
            });
        },
        enumerable: true,
        configurable: true
    });
    ;
    TableLayoutComponent.prototype.ngOnChanges = function () {
        this.keys = Object.keys(this.records[0]);
    };
    TableLayoutComponent.prototype.onChange = function (event, test) {
        var _this = this;
        console.log(test);
        this.filterKey = event.target.id;
        this.filterValue = "" + test;
        console.log(this.originalData.length);
        if (test === '') {
            this._records = this.originalData;
        }
        else {
            this._records = this.records.filter(function (element, index, array) { return _this.filter(element, index, array); });
        }
    };
    TableLayoutComponent.prototype.filter = function (element, index, array) {
        return this.map[element.id] > 0;
    };
    TableLayoutComponent.prototype.matchSegment = function (input) {
        for (var prop in this.arrayToBeMatched) {
            var subArray = this.arrayToBeMatched[prop];
            for (var j = 0; j < subArray.length; j++) {
                var valueToBeMatched = subArray[j];
                if (isNaN(parseFloat(valueToBeMatched)) && isNaN(parseFloat(input))) {
                    if (valueToBeMatched.indexOf(input) >= 0) {
                        this.map[prop]++;
                    }
                }
                else if (!isNaN(parseFloat(valueToBeMatched)) && !isNaN(parseFloat(input))) {
                    var num1 = parseFloat(valueToBeMatched);
                    var num2 = parseFloat(input);
                    if (num2 >= num1 + 10 && num2 <= num1 - 10) {
                        this.map[prop]++;
                    }
                }
            }
        }
    };
    TableLayoutComponent.prototype.onDelete = function (record) {
        console.log(record);
        this.originalData = this.removeFromArray(this.originalData, record.id);
        this._records = this.removeFromArray(this._records, record.id);
    };
    TableLayoutComponent.prototype.removeFromArray = function (originalArray, id) {
        var arr;
        for (var i = 0; i < originalArray.length; i++) {
            if ((originalArray[i]).id === id) {
                arr = originalArray.splice(i, 1);
                break;
            }
        }
        return originalArray;
    };
    TableLayoutComponent.prototype.clearMap = function (inputRecords) {
        this.map = {};
        for (var i = 0; i < inputRecords.length; i++) {
            this.map[inputRecords[i].id] = 0;
        }
    };
    TableLayoutComponent.prototype.onChangeInput = function (id, value, key) {
        var record = this._records[id];
        if (key === 'Wins') {
            record.Points = value * 25 + this.pointsMap[record.Position];
        }
        else {
            record.Points = record.Wins * 25 + this.pointsMap[value];
        }
        if (isNaN(record.Points)) {
            record.Points = '';
        }
    };
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Array), 
        __metadata('design:paramtypes', [Array])
    ], TableLayoutComponent.prototype, "records", null);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', String)
    ], TableLayoutComponent.prototype, "caption", void 0);
    TableLayoutComponent = __decorate([
        core_1.Component({
            selector: 'ct-table',
            templateUrl: 'app/shared/table-layout.component.html'
        }), 
        __metadata('design:paramtypes', [])
    ], TableLayoutComponent);
    return TableLayoutComponent;
}());
exports.TableLayoutComponent = TableLayoutComponent;
//# sourceMappingURL=table-layout.component.js.map
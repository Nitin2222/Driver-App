import { Injectable } from '@angular/core';
import { MASTER_DATA} from '../model/master-data';
import { MasterData } from '../model/master-data.model'

@Injectable() 
export  class MasterDataService {
  
  getAddresses() : MasterData {
      //get data through http 
      return MASTER_DATA;
  }
}
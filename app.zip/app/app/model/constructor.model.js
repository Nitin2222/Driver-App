"use strict";
var Constructor = (function () {
    function Constructor() {
    }
    return Constructor;
}());
exports.Constructor = Constructor;
//# sourceMappingURL=constructor.model.js.map
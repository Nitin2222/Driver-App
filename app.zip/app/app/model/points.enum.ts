enum Positions {
    One = 1,
    Two,
    Three,
}
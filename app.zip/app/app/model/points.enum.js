var Positions;
(function (Positions) {
    Positions[Positions["One"] = 1] = "One";
    Positions[Positions["Two"] = 2] = "Two";
    Positions[Positions["Three"] = 3] = "Three";
})(Positions || (Positions = {}));
//# sourceMappingURL=points.enum.js.map
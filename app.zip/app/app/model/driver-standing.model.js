"use strict";
var DriverStanding = (function () {
    function DriverStanding() {
    }
    return DriverStanding;
}());
exports.DriverStanding = DriverStanding;
//# sourceMappingURL=driver-standing.model.js.map
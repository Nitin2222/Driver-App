"use strict";
var MasterData = (function () {
    function MasterData() {
    }
    return MasterData;
}());
exports.MasterData = MasterData;
//# sourceMappingURL=master-data.model.js.map
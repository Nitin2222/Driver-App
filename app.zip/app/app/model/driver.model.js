"use strict";
var Driver = (function () {
    function Driver() {
    }
    return Driver;
}());
exports.Driver = Driver;
//# sourceMappingURL=driver.model.js.map
 import { DriverStanding } from './driver-standing.model'
 export class  StandingList {
    season: number;
    round: number;
    DriverStandings: DriverStanding[];
}


"use strict";
var ViewData = (function () {
    function ViewData() {
    }
    return ViewData;
}());
exports.ViewData = ViewData;
//# sourceMappingURL=view-data.model.js.map
 export class Constructor {
    constructorId: string;
    url: string;
    name: string;
    nationality: string;
}

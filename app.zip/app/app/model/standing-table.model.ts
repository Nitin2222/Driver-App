 import { StandingList } from './standing-list.model'
 export class  StandingTable {
   season: number;
   StandingsLists: StandingList[];
}

 import { StandingTable } from './standing-table.model'
 export class  MasterData {
   xmlns: string;
   series: string;
   url: string;
   limit: number;
   offset : number;
   total: number;
   StandingsTable: StandingTable;
}

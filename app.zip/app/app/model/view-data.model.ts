 export class ViewData {
    Name : string;
    Id : string;
    Code: string;
    URL: string;
    Nationality: string;
    Wins: number;
    Position: number;
    Points:number;
    arrayId:number;
}
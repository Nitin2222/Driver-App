"use strict";
var StandingList = (function () {
    function StandingList() {
    }
    return StandingList;
}());
exports.StandingList = StandingList;
//# sourceMappingURL=standing-list.model.js.map
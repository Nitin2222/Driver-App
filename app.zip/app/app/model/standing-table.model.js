"use strict";
var StandingTable = (function () {
    function StandingTable() {
    }
    return StandingTable;
}());
exports.StandingTable = StandingTable;
//# sourceMappingURL=standing-table.model.js.map
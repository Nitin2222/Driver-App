import { Driver } from './driver.model';
import { Constructor } from './constructor.model';
 export class DriverStanding {
    position: number;
    positionText: string;
    points: number;
    wins: number;
    Driver: Driver;
    Constructors: Constructor[];
  
}

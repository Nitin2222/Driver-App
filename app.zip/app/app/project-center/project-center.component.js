"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var view_data_model_1 = require('../model/view-data.model');
var master_data_service_1 = require('../services/master-data.service');
var ProjectCenterComponent = (function () {
    function ProjectCenterComponent(masterDataService) {
        this.masterDataService = masterDataService;
        this.title = 'Nagarro';
        this.driverData = [];
        this.pointsMap = { '1': 100, '2': 50, '3': 25 };
    }
    ProjectCenterComponent.prototype.ngOnInit = function () {
        this.masterData = this.masterDataService.getAddresses();
        this.filterDataForView();
    };
    ProjectCenterComponent.prototype.filterDataForView = function () {
        var driverStandingArray = this.masterData.StandingsTable.StandingsLists[0].DriverStandings;
        // If data is not sorted by position please sort it by position
        for (var i = 0; i < 3; i++) {
            var driverItem = driverStandingArray[i];
            var viewItem = new view_data_model_1.ViewData();
            viewItem.Id = driverItem.Driver.driverId;
            viewItem.Name = driverItem.Driver.givenName;
            viewItem.Code = driverItem.Driver.code;
            viewItem.URL = driverItem.Driver.url;
            viewItem.Nationality = driverItem.Driver.nationality;
            viewItem.Wins = driverItem.wins;
            viewItem.Position = driverItem.position;
            viewItem.Points = viewItem.Wins * 25 + this.pointsMap[driverItem.position];
            viewItem.arrayId = i;
            this.driverData.push(viewItem);
        }
    };
    ProjectCenterComponent = __decorate([
        core_1.Component({
            selector: 'ct-project-center',
            templateUrl: 'app/project-center/project-center.component.html'
        }), 
        __metadata('design:paramtypes', [master_data_service_1.MasterDataService])
    ], ProjectCenterComponent);
    return ProjectCenterComponent;
}());
exports.ProjectCenterComponent = ProjectCenterComponent;
//# sourceMappingURL=project-center.component.js.map
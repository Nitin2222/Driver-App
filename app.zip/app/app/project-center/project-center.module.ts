import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared.module';
import { ProjectCenterComponent } from './project-center.component';
import { MasterDataService } from '../services/master-data.service'

@NgModule({
    imports: [ SharedModule ],
    declarations: [ ProjectCenterComponent ],
    providers: [ MasterDataService ],
    exports: [ ProjectCenterComponent ]
})
export class ProjectCenterModule { }
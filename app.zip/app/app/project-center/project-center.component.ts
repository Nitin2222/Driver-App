import { Component } from '@angular/core';
import { MasterData } from '../model/master-data.model';
import { ViewData } from '../model/view-data.model';
import { DriverStanding } from '../model/driver-standing.model';
import { MasterDataService } from '../services/master-data.service'

@Component({
    selector: 'ct-project-center',
    templateUrl: 'app/project-center/project-center.component.html'
})
export class ProjectCenterComponent {
   title: string = 'Nagarro';
   masterData: MasterData;
   driverData: ViewData[] = [];
   pointsMap:Object = {'1':100,'2':50,'3':25}
    constructor(private masterDataService: MasterDataService){}
    ngOnInit() {
        this.masterData = this.masterDataService.getAddresses();
        this.filterDataForView();
    }
    
    filterDataForView() {
      let driverStandingArray: Array<DriverStanding> =  this.masterData.StandingsTable.StandingsLists[0].DriverStandings;
        // If data is not sorted by position please sort it by position
        for(var i=0; i<3; i++) {
              let driverItem:any = driverStandingArray[i]; 
              let viewItem: ViewData  = new ViewData();
              viewItem.Id = driverItem.Driver.driverId;
              viewItem.Name = driverItem.Driver.givenName;
              viewItem.Code = driverItem.Driver.code;
              viewItem.URL = driverItem.Driver.url;
              viewItem.Nationality = driverItem.Driver.nationality;
              viewItem.Wins = driverItem.wins;
              viewItem.Position = driverItem.position;
              viewItem.Points = viewItem.Wins*25 + this.pointsMap[driverItem.position];
              viewItem.arrayId = i;
              this.driverData.push (viewItem);
          }
    }
  
 }